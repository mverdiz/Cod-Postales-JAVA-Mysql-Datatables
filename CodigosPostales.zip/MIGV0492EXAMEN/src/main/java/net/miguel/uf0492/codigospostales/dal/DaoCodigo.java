package net.miguel.uf0492.codigospostales.dal;

import net.miguel.uf0492.codigospostales.modelos.Codigo;

public interface DaoCodigo extends Dao<Codigo> {

}
