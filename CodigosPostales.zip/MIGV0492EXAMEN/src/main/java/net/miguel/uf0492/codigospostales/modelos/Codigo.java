package net.miguel.uf0492.codigospostales.modelos;

import java.util.Objects;
import java.util.TreeMap;

public class Codigo {
	
	private Long id;
	private Integer cod;
	private String localidad;
	
	private TreeMap<String, String> errores = new TreeMap<>();
	
	public Codigo(String id, String postal, String localidad) {
		setId(id);
		setCod(cod);
		setLocalidad(localidad);
	}
	
	public Codigo(Long id, Integer cod, String localidad ) {
		setId(id);
		setCod(cod);
		setLocalidad(localidad);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public void setId(String id) {
		if(id.trim().length() == 0) {
			setId((Long)null);
			return;
		}
		
		try {
			setId(Long.parseLong(id));
		} catch (Exception e) {
			errores.put("id", "No es un número");
		}
	}

	public Integer getCod() {
		return cod;
	}

	public void setCod(Integer cod) {
		this.cod = cod;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public TreeMap<String, String> getErrores() {
		return errores;
	}

	public void setErrores(TreeMap<String, String> errores) {
		this.errores = errores;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cod, errores, id, localidad);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Codigo other = (Codigo) obj;
		return Objects.equals(cod, other.cod) && Objects.equals(errores, other.errores) && Objects.equals(id, other.id)
				&& Objects.equals(localidad, other.localidad);
	}

	@Override
	public String toString() {
		return "Codigo [id=" + id + ", cod=" + cod + ", localidad=" + localidad + ", errores=" + errores + "]";
	}	

}
