package net.miguel.uf0492.codigospostales.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import net.miguel.uf0492.codigospostales.modelos.Codigo;

public class DaoCodigoMysql implements DaoCodigo {

	private static final String URL = "jdbc:mysql://localhost:3306/uf0492";
	private static final String USER = "root";
	private static final String PASS = "admin";

	private static final String SQL_SELECT = "SELECT id, cod, localidad FROM codigos";
	private static final String SQL_SELECT_ID = SQL_SELECT + " WHERE id = ?";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new DalException("No se ha encontrado el driver de MySQL", e);
		}
	}

	// SINGLETON
	private DaoCodigoMysql() {
		}

	private static final DaoCodigoMysql INSTANCIA = new DaoCodigoMysql();

	public static DaoCodigoMysql getInstancia() {
		return INSTANCIA;
	}
	// FIN SINGLETON

	@Override
	public Iterable<Codigo> obtenerTodos() {
		try (Connection con = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement pst = con.prepareStatement(SQL_SELECT);
				ResultSet rs = pst.executeQuery()) {
			ArrayList<Codigo> codigos = new ArrayList<>();
			Codigo codigo;

			while (rs.next()) {
				codigo = new Codigo(rs.getLong("id"), rs.getInt("cod"), rs.getString("localidad"));
				codigos.add(codigo);
			}

			return codigos;
		} catch (SQLException e) {
			throw new DalException("Error al pedir los registros", e);
		}
	}

	@Override
	public Codigo obtenerPorId(Long id) {
		try (Connection con = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement pst = con.prepareStatement(SQL_SELECT_ID);) {
			pst.setLong(1, id);

			try (ResultSet rs = pst.executeQuery()) {
				Codigo codigo = null;

				if (rs.next()) {
					codigo = new Codigo(rs.getLong("id"), rs.getInt("cod"), rs.getString("localidad"));
				}

				return codigo;
			}
		} catch (SQLException e) {
			throw new DalException("Error al pedir los registros", e);
		}
	}

	
}
