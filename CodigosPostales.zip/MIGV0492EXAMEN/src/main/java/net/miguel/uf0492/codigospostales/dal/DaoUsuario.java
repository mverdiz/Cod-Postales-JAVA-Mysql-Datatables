package net.miguel.uf0492.codigospostales.dal;

import net.miguel.uf0492.codigospostales.modelos.Usuario;

public interface DaoUsuario extends Dao<Usuario> {

}
