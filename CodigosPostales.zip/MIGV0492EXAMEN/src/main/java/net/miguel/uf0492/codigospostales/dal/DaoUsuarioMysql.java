package net.miguel.uf0492.codigospostales.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import net.miguel.uf0492.codigospostales.modelos.Usuario;

public class DaoUsuarioMysql implements DaoUsuario {

	private static final String URL = "jdbc:mysql://localhost:3306/uf0492";
	private static final String USER = "root";
	private static final String PASS = "admin";

	private static final String SQL_SELECT = "SELECT id, email, password FROM usuarios";
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new DalException("No se ha encontrado el driver de MySQL", e);
		}
	}

	// SINGLETON
	private DaoUsuarioMysql() {
		}

	private static final DaoUsuarioMysql INSTANCIA = new DaoUsuarioMysql();

	public static DaoUsuarioMysql getInstancia() {
		return INSTANCIA;
	}
	// FIN SINGLETON

	@Override
	public Iterable<Usuario> obtenerTodos() {
		try (Connection con = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement pst = con.prepareStatement(SQL_SELECT);
				ResultSet rs = pst.executeQuery()) {
			ArrayList<Usuario> usuarios = new ArrayList<>();
			Usuario usuario;

			while (rs.next()) {
				usuario = new Usuario(rs.getLong("id"), rs.getString("email"), rs.getString("password"));
				usuarios.add(usuario);
			}

			return usuarios;
		} catch (SQLException e) {
			throw new DalException("Error al pedir los registros", e);
		}
	}

}
