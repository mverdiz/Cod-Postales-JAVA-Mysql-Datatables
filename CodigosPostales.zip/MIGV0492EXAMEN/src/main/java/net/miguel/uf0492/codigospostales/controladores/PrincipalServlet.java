package net.miguel.uf0492.codigospostales.controladores;

import java.io.*;

import jakarta.servlet.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;
import net.miguel.uf0492.codigospostales.dal.DaoCodigo;
import net.miguel.uf0492.codigospostales.dal.DaoCodigoMysql;

@WebServlet("/admin/principal")
public class PrincipalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private static final DaoCodigo dao = DaoCodigoMysql.getInstancia();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("codigos", dao.obtenerTodos());
		request.getRequestDispatcher("/WEB-INF/vistas/principal.jsp").forward(request, response);
	}

}
